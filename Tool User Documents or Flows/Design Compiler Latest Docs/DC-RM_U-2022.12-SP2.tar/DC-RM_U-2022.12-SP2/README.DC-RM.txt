####################################################################################
# Synopsys(R) Design Compiler(R) Reference Methodology
# Version: U-2022.12-SP2
# Copyright (C) 2014-2023 Synopsys, Inc. All rights reserved.
####################################################################################
 
Reference methodology provides recommended flow for running the tool:
   - You can start a run by modifying only the Tcl variables in dc_setup.tcl script.
   - You need not modify the dc.tcl file. For further customization, modify the Tcl variables 
	 that point to side scripts to define user-defined constraints and other configurations.

Starting with the S-2021.06-SP4 version, the Design Compiler Reference Methodology scripts 
run only in the Design Compiler NXT tool. If you want to run the Design Compiler or DC 
Explorer tool, you should use the previous RM versions that  are available for download 
on SolvNetPlus.

The Design Compiler Reference Methodology includes options for running the Synopsys 
TestMAX™ DFT and DFTMAX™ and Synopsys Power Compiler(TM) optimization steps. Note that 
additional licenses are required when you run the TestMAX DFT tool or the Power Compiler 
tool within the Design Compiler NXT tool.

For the Design Compiler NXT, the reference methodology provides a common set of 
scripts that you can use to run the tool in either wire load mode or topographical 
mode. This common set of reference scripts also helps you to migrate your existing 
scripts from wire load mode synthesis to topographical mode synthesis. The reference 
script 
   1. Detects when the tool is running in topographical mode
     (When you start the tool using the dcnxt_shell command with the -topographical_mode option.)
	  and
   2. Automatically executes additional steps related to topographical mode synthesis

The Design Compiler Reference Methodology includes support for the following flows:

*  The top-down synthesis flow, including multivoltage synthesis with 
   IEEE 1801, which is also known as Unified Power Format (UPF)

*  The hierarchical synthesis flow, including multivoltage synthesis with UPF

*  RM+ flows:
   - High-performance low-Power (hplp)
   - High connectivity (hc)
   - Timing (tim)

   Embeds the RM+ flows in the base Design Compiler reference methodology 
   script with set_qor_strategy mega-switch and "if" statements to configure the 
   relevant flows. For details about the RM+ flows, see the Synopsys Design Compiler 
   Reference Methodology training slides.

*  Topographical (SPG) and wire load modes

*  NDM and Fusion Library reference library formats

*  Fast compile for Design Planning with IC Compiler II

*  SAIF-based power analysis and optimization

*  Out-of-the-box DFT flows

*  Multicorner-multimode constraints

The Design Compiler Reference Methodology includes 
   - Synopsys Formality(R) reference scripts to verify your synthesis results for all flows
   - Synopsys Verification Compiler(TM) Low Power Static Signoff Reference Methodology scripts 
     for static verification of multivoltage designs

Files Included With the Design Compiler Reference Methodology
=============================================================

------------------------------------------------------------------------------------
File					Description
------------------------------------------------------------------------------------
README.DC-RM.txt                    Information and instructions for setting up and 
                                    running the Design Compiler Reference Methodology 
                                    scripts.

Release_Notes.DC-RM.txt             Release notes for the Design Compiler Reference 
                                    Methodology scripts listing the incremental 
                                    changes in each new version of the scripts.

rm_setup/dc_setup.tcl               Library and design Tcl variables for the Design 
                                    Compiler Reference Methodology, including the 
                                    Formality and Verification Compiler Low Power 
                                    Static scripts. This script is used to customize 
                                    the flow.

rm_dc_scripts/dc.tcl                The Design Compiler Reference Methodology script for 
                                    flat-style synthesis or for block-level synthesis and 
                                    top-level integration in a hierachical flow. You should 
                                    not modify this script as it contains the recommended flow.

rm_dc_scripts/header_dc.tcl         The Design Compiler NXT script to create NDM design
                                    library, output directories, and other non-variable
                                    contents for setup.

rm_dc_scripts/dc.read_design.tcl    The Design Compiler NXT script for reading the RTL.

rm_dc_scripts/mpc.tcl               The Design Compiler NXT script that you can edit to 
                                    add user-minimal physical constraints for Design Planning
                                    flow.

rm_dc_scripts/dft_ports.tcl         The Design Compiler NXT script to create a DFT port.

rm_dc_scripts/
scan_configuration.dc.tcl           The Design Compiler NXT script for DFT scan configuration.

rm_dc_scripts/
dft_test_point.example.tcl          Example of test point definition.

rm_dc_scripts/golden.upf            Example of a golden UPF file for top-down multivoltage 
                                    synthesis.

rm_dc_scripts/
dc.mcmm.scenarios.tcl               Example of the Design Compiler Reference Methodology 
                                    setup file for scenarios in a multicorner-multimode flow.

rm_dc_scripts/fm.tcl                The Formality script to verify top-down synthesis results.

README.VCLP-RM.txt                  Information and instructions for setting up and
                                    running the Verification Compiler Low Power Static 
                                    Signoff Reference Methodology scripts.

Release_Notes.VCLP-RM.txt           Release notes for the Verification Compiler Low 
                                    Power Static Signoff Reference Methodology scripts, 
                                    listing the incremental changes in each new 
                                    version of the scripts.

rm_dc_scripts/vc_lp.tcl             Verification Compiler Low Power Static Signoff 
                                    Reference Methodology script used to perform static 
                                    verification of multivoltage designs for top-down 
                                    synthesis.

rm_utilities/procs_dc.tcl           Defines dcrm_mcmm_filename proc to generate file names 
                                    for multicorner-multimode (MCMM) related files.

rm_utilities/procs_global.tcl       Defines rm_source proc.
------------------------------------------------------------------------------------


Instructions:
Using the Design Compiler Reference Methodology in a Top-Down Flow
==================================================================

The file names in the following instructions refer to variable names that are defined in 
the dc_setup.tcl file. Default file names are assigned for all variables. You can customize 
your flow by changing the names to match the names of the files used in your flow.

This section provides instructions for the following tasks:

*  Setting up the scripts for a top-down flow
*  Running the scripts in a top-down flow

Setting Up the Scripts for a Top-Down flow
------------------------------------------

To set up the Design Compiler Reference Methodology scripts for a top-down flow,

1. Copy the reference methodology files to a new location.

2. Edit the dc_setup.tcl script to customize your Design Compiler setup.
     
   o  Set the design name, search path, and library information for your design:

      *  DESIGN_NAME: Name of your design
      *  ADDITIONAL_SEARCH_PATH: Provides a list of paths to add to search path
      *  TARGET_LIBRARY_FILES: Provides target library for synthesis 
      *  REFERENCE_LIBRARY: Provides a list of reference libraries
      *  TECH_FILE: Technology file of the reference library 
    
   o  Include a list of your RTL files in the RTL_SOURCE_FILES variable.

      Use only file names and take advantage of the search_path setting to keep
      your files portable.

      The Design Compiler NXT tool can read and determine the dependencies between RTL 
      files automatically. To use this capability, select autoread for the RTL_SOURCE_FORMAT
      variable. You can specify a list of RTL files and RTL file directories with the 
      RTL_SOURCE_FILES variable.

      Alternatively, you can use a custom script to read the RTL files in the 
      Design Compiler NXT and Formality tools. To use this capability, override the 
      DCRM_RTL_READ_SCRIPT and FMRM_RTL_READ_SCRIPT variables in the dc_setup.tcl 
      file to define the names of these scripts.

   o  Multicore optimization is enabled by default and set to use 8 cores. The number of 
      cores can be changed using the DC_MAX_CORES variable.

      Ensure that you have sufficient cores and sufficient copies of all feature 
      licenses to support your settings.

   o  Specify a common cache directory with the DCRM_ALIB_CACHE variable if you want to 
      save some runtime in subsequent Design Compiler NXT sessions.

   o  Ensure that you have input files that you need for multicorner-multimode flow.

      The dc.mcmm.scenarios.tcl setup file shows a general example of a scenario 
      setup file for a multicorner-multimode flow.

      You must have the following file:

      *  DCRM_MCMM_SCENARIOS_SETUP_FILE: The scenario setup file

      You also need scenario-specific versions of the following files:

      *  DCRM_CONSTRAINTS_INPUT_FILE: Provides the logic design constraints

      *  DCRM_SDC_INPUT_FILE: Provides the Synopsys Design Constraints (SDC) constraints

      *  DCRM_MV_SET_VOLTAGE_INPUT_FILE: Provides the set_voltage commands

      Scenario-specific files should use the base file name defined in dc_setup.tcl. 
      By default, the naming convention inserts the scenario name before the file 
      extension. You can configure how the scenario name is added to the base file name 
      by changing the dcrm_mcmm_filename Tcl procedure defined in procs_dc.tcl.

      This naming style applies to both input and output files in the 
      multicorner-multimode flow.

   o  Specify floorplan for topographical synthesis by using the DCRM_DCT_DEF_INPUT_FILE
      or DCRM_DCT_FLOORPLAN_INPUT_FILE variable.

   o  If UPF input file is available, modify the following variables according to your 
      design intent:
   
      *  UPF_FILE: The UPF setup file
   
      *  UPF_MODE: Allows to select between golden and prime modes. Select none if no UPF 
	     file is available.
   
      *  DCRM_MV_SET_VOLTAGE_INPUT_FILE: Provides the set_voltage commands
   
      The golden.upf file shows examples of UPF input files. 
      
      You can also use Visual UPF in the Synopsys Design Vision(TM) graphical user 
      interface (GUI) to generate a UPF template for your design. To open the Visual 
      UPF dialog box, choose Power > Visual UPF. For information about Visual UPF, 
      see the Power Compiler User Guide.
   
      For information about the golden UPF flow, see the following application note 
      on the Synopsys SolvNetPlus online support site:
   
      *  Golden UPF Flow
   
         https://solvnetplus.synopsys.com/s/article/Golden-UPF-Flow-Application-Note-1576148274574

   o  Customize minimal design-dependent TestMAX DFT variables to match your design:

      *  DFT_CLOCK_LIST: Specify clocks used as DFT signals

      *  DFT_RESET_INFO: Specify resets and presets used as DFT signals

      *  DFT_CONSTANT_INFO: Specify constants used as DFT signals

   o  Customize the optimizations that you want to perform in your design synthesis. 
      Each customization variable includes a comment to describe the purpose and 
      valid options.

      To configure RM+ flow, use the OPTIMIZATION_FLOW variable.
      
      You can also customize the output directories by changing the OUTPUTS_DIR and 
      DCRM_FINAL_DESIGN_ICC2 variables.

Running the Scripts in a Top-Down flow
--------------------------------------

To run the Design Compiler Reference Methodology scripts in a top-down flow,

1. Run your synthesis by using the dc.tcl script.

   For the standard reference methodology flow, run the Design Compiler NXT tool from the 
   directory above the rm_setup directory.

   o  To run the Design Compiler NXT tool, use the following command:

      % dcnxt_shell -topographical_mode -f rm_dc_scripts/dc.tcl | tee dc.log

2. Verify the synthesis results by looking at your log file and studying the reports 
   created in the REPORTS_DIR directory.

   o  When you are satisfied that synthesis completed successfully, proceed to
      Formality verification in the next step.

3. If you are mapping to retention registers, replace the technology library models 
   of those cells with Verilog simulation models for Formality verification.

   For more information, see SolvNet article 24073, "Verifying UPF Designs 
   Containing Retention Registers," at 
   https://solvnetplus.synopsys.com/s/article/Verifying-UPF-Designs-Containing-Retention-Registers-1576148256315.

4. Run your Formality verification by using the fm.tcl script.

   For the standard reference methodology flow, use the following command:

   % fm_shell -f rm_dc_scripts/fm.tcl | tee fm.log
    
5. Perform static verification of the multivoltage design with the Verification 
   Compiler Low Power Static tool by running the Verification Compiler Low Power 
   Static Signoff Reference Methodology script vc_lp.tcl.
   
   For more information, see README.VCLP-RM.txt.


Instructions:
Using the Design Compiler Reference Methodology in a Hierarchical Flow
======================================================================

The file names in the following instructions refer to variable names that are defined in the 
dc_setup.tcl file. The default file names are assigned for all variables. 
You can customize your flow by changing the names to match the names of the files used in your 
flow.

For general hierarchical flow overview information, see the following application notes from 
the Synopsys SolvNetPlus support site:

*  Hierarchical Flow Support in Synopsys Design Compiler Topographical Mode

   https://solvnetplus.synopsys.com/s/article/Hierarchical-Flow-Support-in-Design-Compiler-Topographical-Mode-1576148253382
  
This section provides instructions for the following tasks:

*  Setting up the scripts for block-level synthesis
*  Running the scripts for block-level synthesis
*  Setting up the scripts for top-level synthesis
*  Running the scripts for top-level synthesis

Setting Up the Scripts for Block-Level Synthesis 
-------------------------------------------------------------------

To set up the Design Compiler Reference Methodology scripts for block-level 
synthesis in a hierarchical flow,

1. Edit dc_setup.tcl to set the design name, search path, and library information for your 
   design.

   Only the ${DESIGN_NAME} variable changes between your block-level synthesis runs.

   To enable the hierachical flow mode,
   o  Set the ${DESIGN_STYLE} variable to "hier".
   o  Set the ${PHYSICAL_HIERARCHY_LEVEL} variable to "bottom".

2. Set up separate subdirectories for each hierarchical block by using the design name. 
   Ensure that the dc_setup.tcl file for each block has the ${DESIGN_NAME} variable 
   set to the block design name.

   For a SystemVerilog block design with interface ports, set the SV_WRAPPER_DESIGN_NAME 
   variable to perform the elaboration by using the wrapper design.
   
   For more information, see SolvNetPlus article 016244, "Building SystemVerilog Designs Using 
   a Bottom-Up Approach," at 
   https://solvnetplus.synopsys.com/s/article/Building-SystemVerilog-Designs-Using-a-Bottom-Up-Approach-1576091491932.

3. Follow the top-down flow instructions (described previously) to synthesize each of the 
   hierarchical blocks by using the dc.tcl script.

4. Ensure that you have all the design-specific input files that you need for each 
   hierarchical design.

   The tool picks up these files automatically from the search path defined in dc_setup.tcl. 

5. Ensure that you have the necessary additional multivoltage files for each hierarchical 
   design block.

   The golden.upf file shows examples of UPF input files.

   You can also use Visual UPF in the Design Vision GUI to generate a UPF template for your 
   design. To open the Visual UPF dialog box, choose Power > Visual UPF. 
   For information about Visual UPF, see the Power Compiler User Guide at 
   https://spdocs.synopsys.com/dow_retrieve/latest/dg/dcolh/Default.htm.

6. Ensure that you have the additional multicorner-multimode input files that you need for 
   each hierarchical design block.

   The dc.mcmm.scenarios.tcl file shows a general example of a scenario setup file for a 
   multicorner-multimode flow.

   You must have the following file:

   o  ${DCRM_MCMM_SCENARIOS_SETUP_FILE}, which is the scenario setup file

   You also need scenario-specific versions of the following files:

   o  ${DCRM_CONSTRAINTS_INPUT_FILE}, which provides the logic design constraints
   o  ${DCRM_SDC_INPUT_FILE}, which provides the SDC constraints
   o  ${DCRM_MV_SET_VOLTAGE_INPUT_FILE}, which provides the set_voltage commands

   Scenario-specific files should use the base file name defined in dc_setup.tcl. 
   By default, the naming convention inserts the scenario name before the file extension. 
   You can configure how the scenario name is added to the base file name by changing the 
   dcrm_mcmm_filename Tcl procedure defined in procs_dc.tcl.

   This naming style applies to both input and output files in the multicorner-multimode flow.

Running the Scripts for Block-Level Synthesis
----------------------------------------------------------------

To run the Design Compiler Reference Methodology scripts for block-level 
synthesis in a hierarchical flow,

1. Run synthesis by using the dc.tcl script in each of the block subdirectories.

   For the standard reference methodology flow, run the Design Compiler NXT tool from the 
   directory above the rm_setup directory.

   o  To run the Design Compiler NXT tool, use the following commands:

      % cd ${BLOCK_DESIGN_NAME} 
      % dcnxt_shell -topographical_mode -f rm_dc_scripts/dc.tcl | tee dc.log

2. Verify the synthesis results by looking at your log file and studying the reports 
   created in the ${REPORTS_DIR} directory.

   o  When you are satisfied that synthesis completed successfully, perform verification using 
	  the Formality tool in the next step.

3. Edit the dc_setup.tcl file as needed for Formality verification.

4. If you are mapping to retention registers, replace the technology library models of those 
   cells with Verilog simulation models for Formality verification.

   For more information, see SolvNet article 24073, "Verifying UPF Designs 
   Containing Retention Registers," at 
   https://solvnetplus.synopsys.com/s/article/Verifying-UPF-Designs-Containing-Retention-Registers-1576148256315. 

5. Verify each block for synthesis run separately with the Formality tool by using the fm.tcl 
   script.

   For the standard reference methodology flow, use the following commands:

   % cd ${BLOCK_DESIGN_NAME} 
   % fm_shell -topographical_mode -f rm_dc_scripts/fm.tcl | tee fm.log

6. Verify that all of your block-level runs are completed successfully.


Setting Up the Scripts for Top-Level Synthesis
-----------------------------------------------------------------

To set up the Design Compiler Reference Methodology scripts for top-level 
synthesis in a hierarchical flow,

1. Create an additional subdirectory for your top-level synthesis.

2. Edit dc_setup.tcl at the top-level synthesis.

   To enable the hierachical flow mode,
   o  Set ${DESIGN_STYLE} variable to "hier" 
   o  Set the ${PHYSICAL_HIERARCHY_LEVEL} variable to "top"

3. Define the hierarchical block design names in the dc_setup.tcl file:

   o  DDC_HIER_DESIGNS: List of Synopsys logical database format (.ddc) hierarchical design names

   o  DC_BLOCK_ABSTRACTION_DESIGNS: List of Design Compiler block abstraction hierarchical 
      designs without transparent interface optimization

4. Ensure that you have all the design-specific input files that you need to use in the flow.
 
   The tool picks up these files automatically from the search path defined in dc_setup.tcl.

   Use the same constraints for top-level synthesis that you would use for a top-down flow.

   o  For topographical mode synthesis, include the floorplan for the top-level design.

   o  Use a floorplan where the hierarchical blocks have been partitioned and have fixed 
      placement at the top-level.

   A complete list of the expected input files is provided at the end of this README file.

5. Ensure that you have the additional multivoltage files that you need for this flow. 

   Note:
      The UPF file for top-level synthesis should include UPF design information for the 
	  top-level design only. Block-level UPF information is propagated to the top-level 
	  design as part of the flow.

   You can also use Visual UPF in the Design Vision GUI to generate a UPF template for your 
   design. To open the Visual UPF dialog box, choose Power > Visual UPF. 
   For information about Visual UPF, see the Power Compiler User Guide  at 
   https://spdocs.synopsys.com/dow_retrieve/latest/dg/dcolh/Default.htm..

6. Ensure that you have the multicorner-multimode input files that you need for this flow.

   The dc.mcmm.scenarios.tcl file shows a general example of a scenario setup file for a 
   multicorner-multimode flow.

   You must have the following file:

   o  ${DCRM_MCMM_SCENARIOS_SETUP_FILE}, which is the scenario setup file

   You also need scenario-specific versions of the following files:

   o  ${DCRM_CONSTRAINTS_INPUT_FILE}, which provides the logic design constraints
   o  ${DCRM_SDC_INPUT_FILE}, which provides the SDC constraints
   o  ${DCRM_MV_SET_VOLTAGE_INPUT_FILE}, which provides the set_voltage commands

   Scenario-specific files should use the base file name defined in dc_setup.tcl. 
   By default, the naming convention inserts the scenario name before the file extension. 
   You can configure how the scenario name is added to the base file name by changing the 
   dcrm_mcmm_filename Tcl procedure defined in procs_dc.tcl.

   This naming style applies to both input and output files in the multicorner-multimode flow.

7. For a SystemVerilog design with interface ports, set the 
   ${BLOCK_DESIGN_HAS_SV_INTERFACE_PORTS} variable to true in dc_setup.tcl.
   
   This variable enables the linker to allow a period (.) as an alternative to an underscore 
   (_) during port name matching.

Running the Scripts for Top-Level Synthesis
--------------------------------------------------------------

To run the Design Compiler Reference Methodology scripts for top-level 
synthesis in a hierarchical flow,

1. Run synthesis at the top level by using the dc.tcl script.

   For the standard reference methodology flow, run the Design Compiler NXT tool from the 
   directory above the rm_setup directory.

   o  To run the Design Compiler NXT tool, use the following commands:

      % cd ${TOP_DESIGN_NAME} 
      % dcnxt_shell -topographical_mode -f rm_dc_scripts/dc.tcl | tee dc.log

2. Verify the synthesis results by looking at your log file and studying the reports 
   created in the ${REPORTS_DIR} directory.

   o  When you are satisfied that synthesis completed successfully, perform verification using 
	  the Formality tool in the next step.

3. Edit the dc_setup.tcl file as needed for Formality verification.

4. Verify your top-level synthesis with the Formality tool by using the fm.tcl script.

   For the standard reference methodology flow, use the following commands:

   % cd ${TOP_DESIGN_NAME} 
   % fm_shell -topographical_mode -f rm_dc_scripts/fm.tcl | tee fm.log

5. Perform static verification of the full chip multivoltage design with the Verification 
   Compiler Low Power Static tool, by running the Verification Compiler Low Power 
   Static Signoff Reference Methodology script, vc_lp.tcl.

   For more information, see README.VCLP-RM.txt.

The final written netlist contains the design without the physical hierarchical blocks. 
To obtain the complete synthesized design, the next tool in the flow is expected to read the 
physical block-level synthesis results in addition to the top-level synthesis results.


Input Files for the Design Compiler Reference Methodology
=========================================================

Note:
   Not all of these files are required. You can see the complete list of input files 
   and define the file names in the dc_setup.tcl file.

------------------------------------------------------------------------------------
File                                    Description
------------------------------------------------------------------------------------
RTL_SOURCE_FILES                     List of RTL source files defined in dc_setup.tcl

DCRM_RTL_READ_SCRIPT                 RTL read script

DCRM_MCMM_SCENARIOS_SETUP_FILE       Setup file for scenarios in a multicorner-multimode flow

DCRM_CONSTRAINTS_INPUT_FILE          Logic design constraints for a single scenario

SAIF_FILE                            Activity Interchange Format (SAIF) file for 
                                     power analysis and optimization

DCRM_DEF_INPUT_FILE or 
DCRM_FLOORPLAN_INPUT_FILE            DEF or Tcl floorplan to use for topographical 
                                     mode synthesis

UPF_FILE                             UPF setup file for a multivoltage flow

DCRM_MV_SET_VOLTAGE_INPUT_FILE       set_voltage commands for a multivoltage flow

------------------------------------------------------------------------------------


Output Files from the Design Compiler Reference Methodology
===========================================================

The REPORTS_DIR directory defined in dc_setup.tcl contains reports from the synthesis run.

The OUTPUTS_DIR directory defined in dc_setup.tcl contains synthesis output files, 
including the mapped netlist and the files required for timing analysis, power analysis, 
and formal verification.

The output files generated in the directory pointed by DCRM_FINAL_DESIGN_ICC2 should be 
used as inputs for the IC Compiler Reference II Methodology. The IC Compiler II 
Reference Methodology is the next step in the reference flow and is available as a 
separate download from RMgen on the SolvNetPlus online support site.
